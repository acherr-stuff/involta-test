
// Подключаем стили
import 'normalize.css';
import '../styles/index.scss';

// Подключаем скрипты
import './slider';